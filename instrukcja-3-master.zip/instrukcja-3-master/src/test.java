public class test {

    public static void main(String[] args){
        SpringApplet Test = new SpringApplet();
        Test.init();
    }
}
