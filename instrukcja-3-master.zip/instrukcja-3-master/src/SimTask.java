import java.util.TimerTask;

public class SimTask extends TimerTask {

    public void run() {

    }

}